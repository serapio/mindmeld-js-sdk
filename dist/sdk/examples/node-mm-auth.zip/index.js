
var mmAuth = require('./src/main.js');

mmAuth.start({
  "appID": "ENTER_YOUR_APP_ID",
  "appSecret": "ENTER_YOUR_APP_SECRET",
  "port": 2626
});